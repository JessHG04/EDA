#include "Localidad.h"

ostream &operator<<(ostream &os, Localidad loc){
	os << loc.id << "-" << loc.nombre << "-" << loc.getCoor() << endl;
	os << loc.getInfo();
	return os;
}

Localidad::Localidad(string n){
	nombre = n;
	id = -1;
	// coor e info, se inicializan ellos solos con su constructor
	// por defecto
}

int Localidad::setCoor(int i, int j, vector< vector<char> > &mapa){
	int nuevoId = -1;
	Coordenadas auxiliar(i, j);

	if(coor.getFila() == -1 && coor.getColumna() == -1 && i >= 0 && i < (int) mapa.size() && j >= 0 && j < (int) mapa[0].size()){		 
		if(mapa[i][j] == 'T'){
			coor = auxiliar;
			mapa[i][j] = 'L';
			id = mapa[0].size() * i + j;
			nuevoId = id;
		}
	}
	return nuevoId;		
}

void Localidad::setInfo(InfoTur i){
	info = i;
}
string Localidad::getNombre(){
	return nombre;
}
Coordenadas Localidad::getCoor(){
	return coor;
}
InfoTur Localidad::getInfo(){
	return info;
}

int Localidad::getId(){
	return id;
}
