#include "InfoTur.h"

InfoTur::InfoTur(){
	museo = 0;
	monumento = 0;
	hotel = 0;
	restaurante = 0;
	aeropuerto = false;
	top = "";
}

InfoTur::InfoTur(int mu, int mo, int ho, int r, bool ae){
	if(mu < 0){
		museo = 0;
	}
	else{
		museo = mu;
	}
	monumento = max(0, mo);
	if(ho < 0){
		ho = 0;
	}
	hotel = ho;
	if(r > 0){
		restaurante = r;		
	}
	else{
		restaurante = 0;
	}
	aeropuerto = ae;
	top = "";
	
}

// nuevo constructor: constructor copia.
// Sirve para inicializar nuevos objetos a partir de objetos
// ya creados. No hay que filtrar los valores del parametro =>
// & => es referencia.
// const => no puedo modificar en el constructor inf.
InfoTur::InfoTur(const InfoTur &inf){
	// if(inf.museo < 0){} error... es imposible.
	museo = inf.museo;
	monumento = inf.monumento;
	hotel = inf.hotel;
	restaurante = inf.restaurante;
	aeropuerto = inf.aeropuerto;
	top = inf.top;
}

// el destructor se invoca automaticamente cuando el objeto
// deja de existir, justo antes de su desaparacion!!
InfoTur::~InfoTur(){
	museo = 0;
	monumento = 0;
	hotel = 0;
	restaurante = 0;
	aeropuerto = false;
	top = "";
}

InfoTur &InfoTur::operator=(const InfoTur &de){
	
	museo = de.museo;
	monumento = de.monumento;
	hotel = de.hotel;
	restaurante = de.restaurante;
	aeropuerto = de.aeropuerto;
	top = de.top;
	
	return *this; // devuelvo el objeto implicito.
	// 
}

bool InfoTur::operator!=(const InfoTur &de){
	bool distintos;
	if(museo != de.museo || monumento != de.monumento ||
		hotel != de.hotel || restaurante != de.restaurante
			|| aeropuerto != de.aeropuerto || top != de.top){
		distintos = true;
	}
	else{
		distintos = false;
	}
	return distintos;
	// return !(*this == de);
}

// bool InfoTur::equals(const InfoTur &de){
bool InfoTur::operator==(const InfoTur &de){
	bool iguales;
	if(museo == de.museo && monumento == de.monumento &&
		hotel == de.hotel && restaurante == de.restaurante 
			&& aeropuerto == de.aeropuerto && top == de.top){
		iguales = true; 
	}
	else{
		iguales = false;
	}
	return iguales;
}

vector<int> InfoTur::getInfoTur(){
	vector<int> todo;

	todo.push_back(museo);
	todo.push_back(monumento);
	todo.push_back(hotel);
	todo.push_back(restaurante);
	if(aeropuerto){ // if(aeropuerto == true){
		todo.push_back(1);
	}
	else{
		todo.push_back(0);
	}
	// todo.push_back(aeropuerto?1:0); esto no se puede modificar!!
	return todo;
}

void InfoTur::operator+(const InfoTur &de){
	cout << "hola que tal... como estas... si..ummm" << endl;
}

int InfoTur::operator[](int i){
	if(i == 0){
		return museo;
	}
	if(i == 1){
		return monumento;
	}
	if(i == 2){
		return hotel;
	}
	if(i == 3){
		return restaurante;
	}
	if(i == 4){
		return aeropuerto?1:0;
	}
	return 0;
}

string InfoTur::getMasFrecuente(){
	vector<int> datos;
	int posMayor, i;
	string resultado;

	// este vector no me sirve porque lo quiero lexicografico.
	// datos = getInfoTur();

	datos.push_back(aeropuerto?1:0);
	datos.push_back(hotel);
	datos.push_back(monumento);
	datos.push_back(museo);
	datos.push_back(restaurante);


	posMayor = 0;
	for(i = 1; i < (int) datos.size(); i++){
		if(datos[i] > datos[posMayor]){
			posMayor = i;	
		}
	}
	switch(posMayor){
		case 0:
			resultado = "aeropuerto";
			break;
		case 1:
			resultado = "hotel";
			break;
		case 2:
			resultado = "monumento";
			break;
		case 3:
			resultado = "museo";
			break;
		case 4:
			resultado = "restaurante";
			break;
	}
	return resultado;
}

void InfoTur::setTop(string n){
	top = n;
}

string InfoTur::getTop(){
	return top;
}

ostream &operator<<(ostream &os, const InfoTur &de){
	os << de.museo << " ";
	os << de.monumento << " ";
	os << de.hotel << " ";
	os << de.restaurante << " ";
	os << de.aeropuerto << " ";
	os << de.top;
	os << endl;
	return os;
}


