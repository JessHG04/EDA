#include "Coordenadas.h"

Coordenadas::Coordenadas(){
	fila = -1;
	columna = -1;
}

Coordenadas::Coordenadas(int vfila, int vcolumna){
	if(vfila < 0 || vcolumna < 0){
		fila = -1;
		columna = -1;
	}
	else{
		fila = vfila;
		columna = vcolumna;
	}
}

int Coordenadas::getFila(){
	return fila;
}

int Coordenadas::getColumna(){
	return columna;
}


ostream &operator<<(ostream &os, Coordenadas cor){
	os << "(" << cor.fila << "," << cor.columna << ")";
	return os;
}
