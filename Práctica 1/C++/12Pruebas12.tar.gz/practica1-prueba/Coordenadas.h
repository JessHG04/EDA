#ifndef _COORDENADAS_H
#define _COORDENADAS_H

#include <iostream>
using namespace std;

class Coordenadas{
	friend ostream &operator<<(ostream &os, Coordenadas cor);
	private:
		int fila, columna;
	public:
		Coordenadas();
		Coordenadas(int vfila, int vcolumna);
		int getFila();
		int getColumna();
};


#endif
