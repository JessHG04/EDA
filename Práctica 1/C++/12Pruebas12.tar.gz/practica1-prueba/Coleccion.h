#ifndef _COLECCION_H
#define _COLECCION_H
#include "InfoTur.h"
#include "Coordenadas.h"
#include "Localidad.h"
#include <vector>
#include <iostream>
using namespace std;

class Coleccion{
	friend ostream &operator<<(ostream &os, Coleccion col);
	private:
		vector< vector<char> > mapa;
		vector<Localidad> localidades;
	public:
		Coleccion();
		void lectura(string nombre);
		vector< vector<char> > &getMapa();
		vector<Localidad> &getLocalidades();
		char getCoorMapa(Coordenadas coor);		
};

#endif

