#ifndef _JORGE_TONTO
#define _JORGE_TONTO
#include <iostream>
#include <vector>
#include "Coordenadas.h"
#include "InfoTur.h"
using namespace std;

class Localidad{
	friend ostream &operator<<(ostream &os, Localidad loc);
	private:
		string nombre;
		Coordenadas coor;
		InfoTur info;
		int id;
	public:
		Localidad(string n);
		int setCoor(int i, int j, vector< vector<char> > &mapa);
		void setInfo(InfoTur info);
		string getNombre();
		Coordenadas getCoor();
		InfoTur getInfo();
		int getId();
};


#endif
