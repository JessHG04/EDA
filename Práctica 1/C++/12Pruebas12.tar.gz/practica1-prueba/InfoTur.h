// evita que se incluya dos veces el fichero cabecera.
#ifndef _INFOTUR
#define _INFOTUR

#include <iostream>
#include <string>
#include <vector>

using namespace std;

class InfoTur{
	friend ostream &operator<<(ostream &os, const InfoTur &info);
	private:
		int museo;
		int monumento;
		int hotel;
		int restaurante;
		bool aeropuerto;
		string top;
	public:
		InfoTur();
		InfoTur(int mu, int mo, int ho, int r, bool ae);
		InfoTur(const InfoTur &inf);
		~InfoTur();
		InfoTur &operator=(const InfoTur &de);
		bool operator!=(const InfoTur &de);
		bool operator==(const InfoTur &de);
		vector<int> getInfoTur();
		string getMasFrecuente();
		void setTop(string n);
		string getTop();

		// esto no se entrega!!
		void operator+(const InfoTur &de);
		int operator[](int i);

};
#endif
