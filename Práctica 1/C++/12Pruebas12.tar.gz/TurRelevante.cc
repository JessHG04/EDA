#include "Coleccion.h"
#include <iostream>
using namespace std;


// argc => cantidad de argumentos que ponemos en la linea de comandos
// argv => un vector de cadenas con cada uno de los argumentos
// (incluyendo el nombre del programa, en JAVA no)
int main(int argc, char *argv[]){
	Coleccion nikol;
	vector<Localidad> locas;
	string masFrecuente;
	
	if(argc == 2){ // argv[0] => nombrePrograma argv[1] => nombreFichero
		nikol.lectura(argv[1]);
		locas = nikol.getLocalidades();
		for(int i = 0; i < (int) locas.size(); i++){
			cout << locas[i].getNombre() << " ";
			cout << locas[i].getCoor() << ": ";
			// el mas frecuente y el mas relevante
			// separados por un guion.
			masFrecuente = locas[i].getInfo().getMasFrecuente();
			cout << masFrecuente;
			if(locas[i].getInfo().getTop() != ""){
				cout << " - " << locas[i].getInfo().getTop();
			}
			cout << endl;
		}
	}
	return 0;
}
