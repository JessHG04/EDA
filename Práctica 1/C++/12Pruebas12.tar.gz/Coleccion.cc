#include "Coleccion.h"
#include <fstream>
#include <sstream>
using namespace std;


ostream &operator<<(ostream &os, Coleccion col){
	for(int i = 0; i < (int) col.mapa.size(); i++){
		for(int j = 0; j < (int) col.mapa[0].size(); j++){
			cout << col.mapa[i][j];
		}
		cout << endl;
	}
	for(int i = 0; i < (int) col.localidades.size(); i++){
		cout << col.localidades[i];
	}
	return os;
}

Coleccion::Coleccion(){
	// se inicializan solos con sus constructores por defecto.
}

void Coleccion::lectura(string nombre){
	string linea, nombreLocalidad, item;
	int ci, cj, cantidad;
	ifstream fich;
	string tor;
	int nmus, nhot, nres, nmon;
	bool ae;

	fich.open(nombre.c_str()); // abro el fichero...
	if(fich.is_open()){ // si el fichero esta abrido
		// pillamos el mapa
		getline(fich, linea); // lee a fucking line
		while(fich.eof() == false && linea != "<LOCALIDAD>"){
			// 1. Crear un vector de caracter  vector<char>
			vector<char> ass;		
			for(int i = 0; i < (int) linea.length(); i++){
				ass.push_back(linea[i]);	
			}		
			// 2. Meter el vector de caracteres en el mapa.
			mapa.push_back(ass);
			getline(fich, linea);
		}

		// pillamos las localidades
		while(fich.eof() == false){
			// leo el nombre de la localidad
			getline(fich, nombreLocalidad);
			// leo las coordenadas
			fich >> ci >> cj;
			// creo la localidad con los datos leidos
			Localidad loc(nombreLocalidad);
			loc.setCoor(ci, cj, mapa);
			
			getline(fich, linea); // se salta el info.
			getline(fich, linea); // leeee una linea de informacion.		
			nmon = nmus = nhot = nres = 0;
			tor = "";
			ae = false;	
			while(fich.eof() == false && linea != "<LOCALIDAD>"){
				// Comprobar si es un top!!!
				// si es top, lo guardais top
				if(linea[0] == '*'){
					tor = linea;
				}
				else{
					// si no es top partimos linea
					stringstream ss(linea);
					ss >> item >> cantidad;			
					if(item == "museo"){
						nmus = cantidad;
					}
					if(item == "hotel"){
						nhot = cantidad;
					}
					if(item == "restaurante"){
						nres = cantidad;
					}
					if(item == "aeropuerto"){
						ae = true;
					}
					if(item == "monumento"){
						nmon = cantidad;
					}
				}		
				getline(fich, linea);		
			}
			// Crear un infoTur con la informacion leida
			InfoTur nuevo(nmus, nmon, nhot, nres, ae);
			nuevo.setTop(tor);
			loc.setInfo(nuevo);
			if(loc.getCoor().getFila() != -1){
				localidades.push_back(loc);
			}
			// Modificar la localidad con el infotur leido
			// y meterlo en el vector de localidades!!!
			
		}
		fich.close();
	}
}

vector< vector<char> > &Coleccion::getMapa(){
	return mapa;
}

vector<Localidad> &Coleccion::getLocalidades(){
	return localidades;
}	

char Coleccion::getCoorMapa(Coordenadas coor){
	char letra = 'X';
	if(coor.getFila() >= 0 && coor.getColumna() >= 0 &&
		coor.getFila() <(int) mapa.size() && coor.getColumna() < (int) mapa[0].size()){
		letra = mapa[coor.getFila()][coor.getColumna()];
	}

	return letra;
}	
