
public class xCol02 {
	public static void main(String [] args) {
		TurRelevante.main(new String [] {"xCol02.dat"});
	}
}
