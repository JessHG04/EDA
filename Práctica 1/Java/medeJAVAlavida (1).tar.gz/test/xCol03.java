
public class xCol03 {
	public static void main(String [] args) {
		TurRelevante.main(new String [] {"xCol03.dat"});
	}
}
