
public class xCol01 {
	public static void main(String [] args) {
		TurRelevante.main(new String [] {"xCol01.dat"});
	}
}
