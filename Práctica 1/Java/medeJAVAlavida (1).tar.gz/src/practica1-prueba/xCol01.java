
public class xCol01 {
	public static void main(String [] args) {
		(new TurRelevante()).main(new String [] {"xCol01.dat"});
	}
}
